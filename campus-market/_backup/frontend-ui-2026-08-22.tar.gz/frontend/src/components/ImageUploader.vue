<script setup>
import { ref } from 'vue'
import { toast } from '../utils/toast'

const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  max: { type: Number, default: 3 },
})

const emit = defineEmits(['update:modelValue'])
const inputRef = ref(null)

function trigger() {
  inputRef.value?.click()
}

function onFile(e) {
  const files = Array.from(e.target.files || [])
  const remaining = props.max - props.modelValue.length
  if (remaining <= 0) {
    toast(`最多上传 ${props.max} 张图片`, 'error')
    return
  }
  const selected = files.slice(0, remaining)
  for (const f of selected) {
    if (!f.type.startsWith('image/')) {
      toast('仅支持图片文件', 'error')
      continue
    }
    const url = URL.createObjectURL(f)
    emit('update:modelValue', [...props.modelValue, { file: f, preview: url }])
  }
  e.target.value = ''
}

function remove(i) {
  const next = [...props.modelValue]
  URL.revokeObjectURL(next[i].preview)
  next.splice(i, 1)
  emit('update:modelValue', next)
}
</script>

<template>
  <div class="grid grid-cols-3 gap-3">
    <div
      v-for="(img, i) in modelValue"
      :key="i"
      class="relative aspect-square rounded-xl overflow-hidden border border-slate-200 group"
    >
      <img :src="img.preview" class="w-full h-full object-cover" alt="预览" />
      <button
        type="button"
        class="absolute top-1 right-1 w-6 h-6 rounded-full bg-slate-800/70 text-white text-xs opacity-0 group-hover:opacity-100 transition"
        @click="remove(i)"
      >✕</button>
    </div>
    <button
      v-if="modelValue.length < max"
      type="button"
      class="aspect-square rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:border-brand-400 hover:text-brand-500 hover:bg-brand-50 transition"
      @click="trigger"
    >
      <span class="text-2xl">＋</span>
      <span class="text-xs mt-1">上传图片</span>
      <span class="text-[10px] text-slate-300">{{ modelValue.length }}/{{ max }}</span>
    </button>
    <input ref="inputRef" type="file" accept="image/*" multiple class="hidden" @change="onFile" />
  </div>
</template>

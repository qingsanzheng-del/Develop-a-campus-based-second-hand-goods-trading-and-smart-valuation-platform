<script setup>
defineProps({
  text: { type: String, required: true },
})
</script>

<template>
  <span class="inline-block px-2 py-0.5 rounded-md bg-brand-50 text-brand-700 text-xs border border-brand-100">
    {{ text }}
  </span>
</template>

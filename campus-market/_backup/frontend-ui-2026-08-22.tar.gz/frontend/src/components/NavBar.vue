<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const router = useRouter()
const auth = useAuthStore()

function logout() {
  auth.logout()
  router.push('/')
}
</script>

<template>
  <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
    <div class="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
      <router-link to="/" class="flex items-center gap-2 text-brand-700 font-bold text-lg">
        <span class="text-2xl">🎓</span>
        <span>校园二手集市</span>
      </router-link>
      <nav class="flex items-center gap-1 text-sm">
        <router-link
          to="/"
          class="px-3 py-2 rounded-lg hover:bg-brand-50 hover:text-brand-700"
          active-class="text-brand-700 font-semibold"
        >首页</router-link>
        <router-link
          to="/publish"
          class="px-3 py-2 rounded-lg hover:bg-brand-50 hover:text-brand-700"
          active-class="text-brand-700 font-semibold"
        >发布</router-link>
        <template v-if="auth.token">
          <router-link
            v-if="auth.isAdmin"
            to="/admin"
            class="px-3 py-2 rounded-lg hover:bg-brand-50 hover:text-brand-700"
            active-class="text-brand-700 font-semibold"
          >管理</router-link>
          <router-link
            to="/me"
            class="px-3 py-2 rounded-lg hover:bg-brand-50 hover:text-brand-700"
            active-class="text-brand-700 font-semibold"
          >我的</router-link>
          <button
            class="ml-2 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
            @click="logout"
          >退出</button>
        </template>
        <template v-else>
          <router-link
            to="/login"
            class="ml-2 px-4 py-1.5 rounded-lg bg-brand-600 text-white hover:bg-brand-700"
          >登录</router-link>
        </template>
      </nav>
    </div>
  </header>
</template>

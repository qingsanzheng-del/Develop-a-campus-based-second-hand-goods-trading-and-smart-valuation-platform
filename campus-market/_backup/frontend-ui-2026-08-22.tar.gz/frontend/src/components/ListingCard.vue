<script setup>
defineProps({
  listing: { type: Object, required: true },
})
</script>

<template>
  <router-link
    :to="`/listing/${listing.id}`"
    class="group block bg-white rounded-2xl overflow-hidden border border-slate-200 hover:shadow-lg hover:-translate-y-0.5 transition"
    :class="listing.status === 'sold' ? 'opacity-60' : ''"
  >
    <div class="relative aspect-square bg-slate-100">
      <img
        v-if="listing.images && listing.images.length"
        :src="listing.images[0]"
        :alt="listing.title"
        class="w-full h-full object-cover"
        loading="lazy"
      />
      <div v-else class="w-full h-full flex items-center justify-center text-4xl">🛍️</div>
      <span
        v-if="listing.status === 'sold'"
        class="absolute top-2 right-2 px-2 py-1 rounded-lg bg-slate-800/80 text-white text-xs font-semibold"
      >已售</span>
      <span
        v-else-if="listing.status === 'delisted'"
        class="absolute top-2 right-2 px-2 py-1 rounded-lg bg-slate-500/80 text-white text-xs font-semibold"
      >已下架</span>
    </div>
    <div class="p-3">
      <h3 class="font-medium text-slate-800 truncate group-hover:text-brand-700">{{ listing.title }}</h3>
      <div class="mt-1 text-brand-600 font-bold">
        ¥{{ listing.price_min }}{{ listing.price_max && listing.price_max !== listing.price_min ? ` - ${listing.price_max}` : '' }}
      </div>
      <div class="mt-2 flex items-center justify-between text-xs text-slate-400">
        <span class="truncate">🧑‍🎓 {{ listing.seller_name }}</span>
        <span>{{ listing.created_at?.slice(0, 10) }}</span>
      </div>
    </div>
  </router-link>
</template>

<template>
  <div class="bg-white rounded-2xl overflow-hidden border border-slate-200 animate-pulse">
    <div class="aspect-square bg-slate-100"></div>
    <div class="p-3 space-y-2">
      <div class="h-4 bg-slate-100 rounded"></div>
      <div class="h-4 w-2/3 bg-slate-100 rounded"></div>
      <div class="h-3 w-1/2 bg-slate-100 rounded"></div>
    </div>
  </div>
</template>

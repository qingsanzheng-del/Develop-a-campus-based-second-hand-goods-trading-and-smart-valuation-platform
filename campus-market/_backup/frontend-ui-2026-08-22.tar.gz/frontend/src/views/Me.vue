<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useAuthStore } from '../stores/auth'
import { toast } from '../utils/toast'

const auth = useAuthStore()
const items = ref([])
const loading = ref(true)

const STATUS_TEXT = { active: '在售', sold: '已售', delisted: '已下架', pending: '待审核' }
const STATUS_CLASS = {
  active: 'bg-emerald-100 text-emerald-700',
  sold: 'bg-slate-200 text-slate-600',
  delisted: 'bg-slate-100 text-slate-500',
  pending: 'bg-amber-100 text-amber-700',
}

async function load() {
  loading.value = true
  try {
    const { data } = await api.get('/listings/mine')
    items.value = data
  } finally {
    loading.value = false
  }
}

async function setStatus(item, status) {
  try {
    await api.patch(`/listings/${item.id}/status`, { status })
    toast(status === 'sold' ? '已标记售出' : '已下架', 'success')
    load()
  } catch (e) {
    // 拦截器已提示
  }
}

onMounted(load)
</script>

<template>
  <div class="max-w-4xl mx-auto px-4 py-6">
    <h1 class="text-xl font-bold text-slate-800 mb-1">个人中心</h1>
    <p class="text-sm text-slate-400 mb-6">👋 {{ auth.user?.username }}，管理你发布的商品</p>

    <div v-if="loading" class="text-center py-16 text-slate-400">加载中…</div>
    <div v-else-if="items.length === 0" class="text-center py-16 text-slate-400">
      <div class="text-5xl mb-3">📦</div>
      <p>你还没有发布任何商品</p>
      <router-link to="/publish" class="text-brand-600 hover:underline mt-2 inline-block">去发布</router-link>
    </div>
    <div v-else class="space-y-3">
      <div
        v-for="item in items"
        :key="item.id"
        class="bg-white rounded-xl border border-slate-200 p-4 flex items-center gap-4"
      >
        <img
          v-if="item.images && item.images.length"
          :src="item.images[0]"
          class="w-20 h-20 rounded-lg object-cover bg-slate-100"
          alt=""
        />
        <div v-else class="w-20 h-20 rounded-lg bg-slate-100 flex items-center justify-center text-2xl">🛍️</div>
        <div class="flex-1 min-w-0">
          <div class="font-medium text-slate-800 truncate">{{ item.title }}</div>
          <div class="text-brand-600 font-bold mt-0.5">¥{{ item.price_min }}</div>
          <span class="inline-block mt-1 px-2 py-0.5 rounded-md text-xs" :class="STATUS_CLASS[item.status]">
            {{ STATUS_TEXT[item.status] || item.status }}
          </span>
        </div>
        <div class="flex flex-col gap-2">
          <router-link
            :to="`/listing/${item.id}`"
            class="px-3 py-1.5 rounded-lg border border-slate-200 text-sm text-center hover:bg-slate-50"
          >查看</router-link>
          <button
            v-if="item.status === 'active'"
            class="px-3 py-1.5 rounded-lg bg-emerald-500 text-white text-sm hover:bg-emerald-600"
            @click="setStatus(item, 'sold')"
          >标记已售</button>
          <button
            v-if="item.status === 'active'"
            class="px-3 py-1.5 rounded-lg border border-slate-200 text-sm hover:bg-slate-50"
            @click="setStatus(item, 'delisted')"
          >下架</button>
        </div>
      </div>
    </div>
  </div>
</template>

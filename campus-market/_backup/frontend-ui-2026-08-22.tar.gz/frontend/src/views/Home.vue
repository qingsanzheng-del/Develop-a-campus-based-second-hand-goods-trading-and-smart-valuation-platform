<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import ListingCard from '../components/ListingCard.vue'
import SkeletonCard from '../components/SkeletonCard.vue'

const CATEGORIES = ['全部', '数码', '书籍', '生活用品', '服饰鞋包', '运动户外', '其他']

const listings = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = 12
const category = ref('')
const keyword = ref('')
const loading = ref(true)

async function load() {
  loading.value = true
  try {
    const { data } = await api.get('/listings', {
      params: { category: category.value, q: keyword.value, page: page.value, page_size: pageSize },
    })
    listings.value = data.items
    total.value = data.total
  } finally {
    loading.value = false
  }
}

function selectCategory(c) {
  category.value = c === '全部' ? '' : c
  page.value = 1
  load()
}

function search() {
  page.value = 1
  load()
}

const totalPages = () => Math.max(1, Math.ceil(total.value / pageSize))

onMounted(load)
</script>

<template>
  <div class="max-w-6xl mx-auto px-4 py-6">
    <div class="mb-6">
      <h1 class="text-xl font-bold text-slate-800">发现好物</h1>
      <p class="text-sm text-slate-400 mt-1">AI 智能估价，让每一件闲置找到新主人</p>
    </div>

    <div class="flex flex-col sm:flex-row sm:items-center gap-3 mb-6">
      <div class="flex flex-wrap gap-2">
        <button
          v-for="c in CATEGORIES"
          :key="c"
          class="px-3 py-1.5 rounded-full text-sm border transition"
          :class="
            category === c || (c === '全部' && category === '')
              ? 'bg-brand-600 text-white border-brand-600'
              : 'bg-white text-slate-600 border-slate-200 hover:border-brand-300'
          "
          @click="selectCategory(c)"
        >
          {{ c }}
        </button>
      </div>
      <div class="sm:ml-auto flex gap-2">
        <input
          v-model="keyword"
          type="text"
          class="px-3 py-1.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
          placeholder="搜索商品…"
          @keyup.enter="search"
        />
        <button
          class="px-4 py-1.5 rounded-lg bg-brand-600 text-white text-sm hover:bg-brand-700"
          @click="search"
        >
          搜索
        </button>
      </div>
    </div>

    <div v-if="loading" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
      <SkeletonCard v-for="i in 8" :key="i" />
    </div>
    <div v-else-if="listings.length === 0" class="text-center py-20 text-slate-400">
      <div class="text-5xl mb-3">🔍</div>
      <p>没有找到相关商品</p>
    </div>
    <div v-else class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
      <ListingCard v-for="l in listings" :key="l.id" :listing="l" />
    </div>

    <div v-if="totalPages() > 1" class="flex items-center justify-center gap-3 mt-8">
      <button
        :disabled="page <= 1"
        class="px-4 py-1.5 rounded-lg border border-slate-200 text-sm disabled:opacity-40"
        @click="page--; load()"
      >上一页</button>
      <span class="text-sm text-slate-500">{{ page }} / {{ totalPages() }}</span>
      <button
        :disabled="page >= totalPages()"
        class="px-4 py-1.5 rounded-lg border border-slate-200 text-sm disabled:opacity-40"
        @click="page++; load()"
      >下一页</button>
    </div>
  </div>
</template>

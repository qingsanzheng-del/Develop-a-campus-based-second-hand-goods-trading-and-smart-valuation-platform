<script setup>
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import api from '../api'
import { useAuthStore } from '../stores/auth'

const router = useRouter()
const route = useRoute()
const auth = useAuthStore()

const username = ref('')
const password = ref('')
const loading = ref(false)

async function submit() {
  if (!username.value || !password.value) return
  loading.value = true
  try {
    const { data } = await api.post('/auth/login', {
      username: username.value,
      password: password.value,
    })
    auth.setAuth(data.token, data.user)
    router.push(route.query.redirect || '/')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="max-w-sm mx-auto mt-16 px-4">
    <div class="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm">
      <h1 class="text-2xl font-bold text-slate-800 text-center">登录</h1>
      <p class="text-sm text-slate-400 text-center mt-1">欢迎回到校园二手集市</p>
      <form class="mt-6 space-y-4" @submit.prevent="submit">
        <div>
          <label class="block text-sm text-slate-600 mb-1">用户名</label>
          <input
            v-model="username"
            type="text"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            placeholder="请输入用户名"
          />
        </div>
        <div>
          <label class="block text-sm text-slate-600 mb-1">密码</label>
          <input
            v-model="password"
            type="password"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            placeholder="请输入密码"
          />
        </div>
        <button
          type="submit"
          :disabled="loading"
          class="w-full py-2 rounded-lg bg-brand-600 text-white font-medium hover:bg-brand-700 disabled:opacity-60"
        >
          {{ loading ? '登录中…' : '登录' }}
        </button>
      </form>
      <p class="mt-4 text-sm text-center text-slate-400">
        还没有账号？
        <router-link to="/register" class="text-brand-600 hover:underline">去注册</router-link>
      </p>
    </div>
  </div>
</template>

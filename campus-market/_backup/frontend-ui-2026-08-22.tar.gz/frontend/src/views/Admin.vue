<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { toast } from '../utils/toast'

const TABS = [
  { key: '', label: '全部' },
  { key: 'pending', label: '待审核' },
  { key: 'active', label: '在售' },
  { key: 'sold', label: '已售' },
  { key: 'delisted', label: '已下架' },
]

const STATUS_TEXT = { active: '在售', sold: '已售', delisted: '已下架', pending: '待审核' }
const STATUS_CLASS = {
  active: 'bg-emerald-100 text-emerald-700',
  sold: 'bg-slate-200 text-slate-600',
  delisted: 'bg-slate-100 text-slate-500',
  pending: 'bg-amber-100 text-amber-700',
}

const tab = ref('')
const items = ref([])
const loading = ref(true)

async function load() {
  loading.value = true
  try {
    const { data } = await api.get('/admin/listings', { params: { status: tab.value } })
    items.value = data
  } finally {
    loading.value = false
  }
}

function switchTab(t) {
  tab.value = t
  load()
}

async function approve(item) {
  await api.post(`/admin/listings/${item.id}/approve`)
  toast('已通过审核', 'success')
  load()
}

async function delist(item) {
  await api.post(`/admin/listings/${item.id}/delist`)
  toast('已下架', 'success')
  load()
}

async function remove(item) {
  if (!confirm(`确定删除「${item.title}」？此操作不可恢复。`)) return
  await api.delete(`/admin/listings/${item.id}`)
  toast('已删除', 'success')
  load()
}

onMounted(load)
</script>

<template>
  <div class="max-w-5xl mx-auto px-4 py-6">
    <h1 class="text-xl font-bold text-slate-800 mb-1">管理后台</h1>
    <p class="text-sm text-slate-400 mb-6">审核、下架与删除商品</p>

    <div class="flex gap-2 mb-5">
      <button
        v-for="t in TABS"
        :key="t.key"
        class="px-3 py-1.5 rounded-full text-sm border transition"
        :class="
          tab === t.key
            ? 'bg-brand-600 text-white border-brand-600'
            : 'bg-white text-slate-600 border-slate-200 hover:border-brand-300'
        "
        @click="switchTab(t.key)"
      >
        {{ t.label }}
      </button>
    </div>

    <div v-if="loading" class="text-center py-16 text-slate-400">加载中…</div>
    <div v-else-if="items.length === 0" class="text-center py-16 text-slate-400">
      <div class="text-5xl mb-3">🗂️</div>
      <p>暂无相关商品</p>
    </div>
    <div v-else class="space-y-3">
      <div
        v-for="item in items"
        :key="item.id"
        class="bg-white rounded-xl border border-slate-200 p-4 flex items-center gap-4"
      >
        <img
          v-if="item.images && item.images.length"
          :src="item.images[0]"
          class="w-20 h-20 rounded-lg object-cover bg-slate-100"
          alt=""
        />
        <div v-else class="w-20 h-20 rounded-lg bg-slate-100 flex items-center justify-center text-2xl">🛍️</div>
        <div class="flex-1 min-w-0">
          <div class="font-medium text-slate-800 truncate">{{ item.title }}</div>
          <div class="text-sm text-slate-400 mt-0.5">
            {{ item.category }} · ¥{{ item.price_min }} · {{ item.seller_name }}
          </div>
          <div class="mt-1 flex gap-2">
            <span class="inline-block px-2 py-0.5 rounded-md text-xs" :class="STATUS_CLASS[item.status]">
              {{ STATUS_TEXT[item.status] || item.status }}
            </span>
            <span v-if="item.is_flagged" class="inline-block px-2 py-0.5 rounded-md text-xs bg-rose-100 text-rose-700">
              ⚠ 违规待审
            </span>
          </div>
        </div>
        <div class="flex flex-col gap-2">
          <button
            v-if="item.status === 'pending'"
            class="px-3 py-1.5 rounded-lg bg-emerald-500 text-white text-sm hover:bg-emerald-600"
            @click="approve(item)"
          >通过</button>
          <button
            v-if="item.status !== 'delisted'"
            class="px-3 py-1.5 rounded-lg border border-slate-200 text-sm hover:bg-slate-50"
            @click="delist(item)"
          >下架</button>
          <button
            class="px-3 py-1.5 rounded-lg border border-rose-200 text-rose-600 text-sm hover:bg-rose-50"
            @click="remove(item)"
          >删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api from '../api'
import TagBadge from '../components/TagBadge.vue'
import { useAuthStore } from '../stores/auth'
import { toast } from '../utils/toast'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()

const listing = ref(null)
const loading = ref(true)
const activeImg = ref(0)

const isOwner = computed(() => listing.value && listing.value.seller_id === auth.user?.id)

async function load() {
  loading.value = true
  try {
    const { data } = await api.get(`/listings/${route.params.id}`)
    listing.value = data
  } finally {
    loading.value = false
  }
}

async function copyContact() {
  try {
    await navigator.clipboard.writeText(listing.value.contact)
    toast('联系方式已复制', 'success')
  } catch {
    toast('复制失败，请手动复制', 'error')
  }
}

async function setStatus(status) {
  try {
    const { data } = await api.patch(`/listings/${listing.value.id}/status`, { status })
    listing.value = data
    toast(status === 'sold' ? '已标记为售出' : '已下架', 'success')
  } catch (e) {
    // 拦截器已提示
  }
}

function delistByOwner() {
  setStatus('delisted')
}

onMounted(load)
</script>

<template>
  <div class="max-w-4xl mx-auto px-4 py-6">
    <div v-if="loading" class="animate-pulse space-y-4">
      <div class="aspect-square sm:aspect-video bg-slate-100 rounded-2xl"></div>
      <div class="h-6 bg-slate-100 rounded w-1/3"></div>
      <div class="h-20 bg-slate-100 rounded"></div>
    </div>

    <template v-else-if="listing">
      <div class="grid sm:grid-cols-2 gap-6">
        <!-- 图片区 -->
        <div>
          <div class="aspect-square bg-slate-100 rounded-2xl overflow-hidden border border-slate-200">
            <img
              v-if="listing.images && listing.images.length"
              :src="listing.images[activeImg]"
              :alt="listing.title"
              class="w-full h-full object-cover"
            />
            <div v-else class="w-full h-full flex items-center justify-center text-6xl">🛍️</div>
          </div>
          <div v-if="listing.images && listing.images.length > 1" class="flex gap-2 mt-2">
            <button
              v-for="(img, i) in listing.images"
              :key="i"
              class="w-16 h-16 rounded-lg overflow-hidden border-2"
              :class="i === activeImg ? 'border-brand-500' : 'border-transparent'"
              @click="activeImg = i"
            >
              <img :src="img" class="w-full h-full object-cover" alt="" />
            </button>
          </div>
        </div>

        <!-- 信息区 -->
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-bold text-slate-800">{{ listing.title }}</h1>
            <span
              v-if="listing.status === 'sold'"
              class="px-2 py-0.5 rounded-lg bg-slate-800/80 text-white text-xs"
            >已售</span>
            <span
              v-else-if="listing.status === 'delisted'"
              class="px-2 py-0.5 rounded-lg bg-slate-500/80 text-white text-xs"
            >已下架</span>
          </div>

          <div class="mt-3 text-3xl font-bold text-brand-600">
            ¥{{ listing.price_min }}<span v-if="listing.price_max && listing.price_max !== listing.price_min" class="text-lg text-slate-400"> - {{ listing.price_max }}</span>
          </div>

          <div class="mt-4 flex flex-wrap gap-2">
            <TagBadge :text="listing.category" />
            <TagBadge :text="`成色：${listing.ai_condition}`" />
            <TagBadge v-for="(t, i) in listing.ai_tags" :key="i" :text="t" />
          </div>

          <div class="mt-5 p-4 bg-slate-50 rounded-xl text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">
            {{ listing.ai_copy || listing.description || '暂无描述' }}
          </div>

          <div class="mt-5 flex items-center justify-between text-sm text-slate-400">
            <span>🧑‍🎓 {{ listing.seller_name }}</span>
            <span>{{ new Date(listing.created_at).toLocaleString() }}</span>
          </div>

          <!-- 联系方式 -->
          <div class="mt-5 p-4 rounded-xl border border-brand-100 bg-brand-50 flex items-center justify-between">
            <div>
              <div class="text-xs text-brand-500">联系方式</div>
              <div class="font-medium text-slate-800 mt-0.5">{{ listing.contact || '未填写' }}</div>
            </div>
            <button
              class="px-4 py-2 rounded-lg bg-brand-600 text-white text-sm hover:bg-brand-700"
              @click="copyContact"
            >📋 一键复制</button>
          </div>

          <!-- 卖家操作 -->
          <div v-if="isOwner && listing.status === 'active'" class="mt-5 flex gap-3">
            <button
              class="flex-1 py-2 rounded-lg bg-emerald-500 text-white text-sm hover:bg-emerald-600"
              @click="setStatus('sold')"
            >标记已售</button>
            <button
              class="flex-1 py-2 rounded-lg border border-slate-200 text-slate-600 text-sm hover:bg-slate-50"
              @click="delistByOwner"
            >下架</button>
          </div>
        </div>
      </div>
    </template>

    <div v-else class="text-center py-20 text-slate-400">
      <p>商品不存在或已删除</p>
      <router-link to="/" class="text-brand-600 hover:underline mt-2 inline-block">返回首页</router-link>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import ImageUploader from '../components/ImageUploader.vue'
import { toast } from '../utils/toast'

const router = useRouter()

const CATEGORIES = ['数码', '书籍', '生活用品', '服饰鞋包', '运动户外', '其他']

const images = ref([])
const description = ref('')
const analyzing = ref(false)
const publishing = ref(false)
const analyzed = ref(false)

const form = ref({
  title: '',
  category: '数码',
  condition: '',
  price_min: 0,
  price_max: 0,
  tags: [],
  valuation_note: '',
  copy: '',
  contact: '',
})

const tagInput = ref('')

async function analyze() {
  if (images.value.length === 0) {
    toast('请先上传 1-3 张图片', 'error')
    return
  }
  analyzing.value = true
  try {
    const fd = new FormData()
    images.value.forEach((img) => fd.append('files', img.file))
    fd.append('description', description.value)
    const { data } = await api.post('/ai/analyze', fd)
    images.value.forEach((img, i) => (img.server = data.images[i]))
    form.value = {
      title: data.title,
      category: data.category,
      condition: data.condition,
      price_min: data.price_min,
      price_max: data.price_max,
      tags: data.tags || [],
      valuation_note: data.valuation_note || '',
      copy: data.copy,
      contact: form.value.contact,
    }
    analyzed.value = true
    toast('AI 估价完成，请确认信息', 'success')
  } catch (e) {
    // 错误已在拦截器提示
  } finally {
    analyzing.value = false
  }
}

function addTag() {
  const t = tagInput.value.trim()
  if (t && !form.value.tags.includes(t)) {
    form.value.tags.push(t)
  }
  tagInput.value = ''
}

function removeTag(i) {
  form.value.tags.splice(i, 1)
}

async function publish() {
  if (!form.value.title.trim()) {
    toast('请填写标题', 'error')
    return
  }
  if (!form.value.contact.trim()) {
    toast('请填写联系方式', 'error')
    return
  }
  publishing.value = true
  try {
    const { data } = await api.post('/listings', {
      title: form.value.title,
      category: form.value.category,
      description: description.value,
      images: images.value.map((img) => img.server),
      ai_condition: form.value.condition,
      ai_tags: form.value.tags,
      ai_copy: form.value.copy,
      price_min: Number(form.value.price_min),
      price_max: Number(form.value.price_max),
      contact: form.value.contact,
    })
    toast(data.status === 'pending' ? '已提交，等待管理员审核' : '发布成功', 'success')
    router.push('/')
  } catch (e) {
    // 错误已在拦截器提示
  } finally {
    publishing.value = false
  }
}
</script>

<template>
  <div class="max-w-3xl mx-auto px-4 py-6">
    <h1 class="text-xl font-bold text-slate-800 mb-1">发布商品</h1>
    <p class="text-sm text-slate-400 mb-6">上传 1-3 张照片，AI 自动识别并智能估价</p>

    <div class="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
      <!-- 上传 -->
      <section>
        <h2 class="font-medium text-slate-700 mb-2">1. 上传照片</h2>
        <ImageUploader v-model="images" :max="3" />
      </section>

      <!-- 补充说明 -->
      <section>
        <h2 class="font-medium text-slate-700 mb-2">2. 补充说明（可选）</h2>
        <textarea
          v-model="description"
          rows="3"
          class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
          placeholder="例如：iPhone 14 用了两年，屏幕有轻微划痕…"
        ></textarea>
      </section>

      <!-- AI 分析按钮 -->
      <section class="text-center">
        <button
          :disabled="analyzing || images.length === 0"
          class="px-8 py-3 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700 disabled:opacity-60"
          @click="analyze"
        >
          <span v-if="analyzing" class="inline-flex items-center gap-2">
            <span class="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"></span>
            AI 识别估价中…
          </span>
          <span v-else>✨ AI 智能估价</span>
        </button>
      </section>

      <!-- 分析中骨架屏 -->
      <div v-if="analyzing" class="space-y-3">
        <p class="text-sm text-brand-600 text-center">AI 正在识别图片并智能估价，约需 10–20 秒，请稍候…</p>
        <div class="space-y-3 animate-pulse">
          <div class="h-5 bg-slate-100 rounded w-1/3"></div>
          <div class="h-4 bg-slate-100 rounded w-2/3"></div>
          <div class="h-4 bg-slate-100 rounded w-1/2"></div>
          <div class="h-20 bg-slate-100 rounded"></div>
        </div>
      </div>

      <!-- 可编辑表单 -->
      <section v-if="analyzed && !analyzing" class="space-y-4">
        <div class="flex items-center justify-between">
          <h2 class="font-medium text-slate-700">3. 确认并完善信息</h2>
          <button
            :disabled="analyzing"
            class="px-3 py-1.5 rounded-lg border border-brand-200 text-brand-600 text-sm hover:bg-brand-50 disabled:opacity-50"
            @click="analyze"
          >🔄 重新估价</button>
        </div>

        <div v-if="form.valuation_note" class="p-3 rounded-lg bg-brand-50 border border-brand-100 text-sm text-slate-600">
          <span class="font-medium text-brand-700">💡 估价依据：</span>{{ form.valuation_note }}
        </div>

        <div>
          <label class="block text-sm text-slate-600 mb-1">标题</label>
          <input
            v-model="form.title"
            type="text"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
          />
        </div>

        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-sm text-slate-600 mb-1">分类</label>
            <select
              v-model="form.category"
              class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            >
              <option v-for="c in CATEGORIES" :key="c" :value="c">{{ c }}</option>
            </select>
          </div>
          <div>
            <label class="block text-sm text-slate-600 mb-1">成色</label>
            <input
              v-model="form.condition"
              type="text"
              class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            />
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-sm text-slate-600 mb-1">最低价（元）</label>
            <input
              v-model.number="form.price_min"
              type="number"
              min="0"
              class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            />
          </div>
          <div>
            <label class="block text-sm text-slate-600 mb-1">最高价（元）</label>
            <input
              v-model.number="form.price_max"
              type="number"
              min="0"
              class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            />
          </div>
        </div>

        <div>
          <label class="block text-sm text-slate-600 mb-1">标签</label>
          <div class="flex flex-wrap gap-2 mb-2">
            <span
              v-for="(t, i) in form.tags"
              :key="i"
              class="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-brand-50 text-brand-700 text-sm"
            >
              {{ t }}
              <button class="text-brand-400 hover:text-brand-700" @click="removeTag(i)">✕</button>
            </span>
          </div>
          <div class="flex gap-2">
            <input
              v-model="tagInput"
              type="text"
              class="flex-1 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
              placeholder="添加标签后回车"
              @keyup.enter="addTag"
            />
            <button class="px-3 py-2 rounded-lg border border-slate-200 text-sm" @click="addTag">添加</button>
          </div>
        </div>

        <div>
          <label class="block text-sm text-slate-600 mb-1">文案</label>
          <textarea
            v-model="form.copy"
            rows="4"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
          ></textarea>
        </div>

        <div>
          <label class="block text-sm text-slate-600 mb-1">联系方式（微信 / QQ / 手机号）</label>
          <input
            v-model="form.contact"
            type="text"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            placeholder="用于买家联系你"
          />
        </div>

        <button
          :disabled="publishing"
          class="w-full py-3 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700 disabled:opacity-60"
          @click="publish"
        >
          {{ publishing ? '发布中…' : '发布' }}
        </button>
      </section>
    </div>
  </div>
</template>

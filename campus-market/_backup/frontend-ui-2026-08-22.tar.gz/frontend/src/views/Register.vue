<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import { useAuthStore } from '../stores/auth'
import { toast } from '../utils/toast'

const router = useRouter()
const auth = useAuthStore()

const username = ref('')
const password = ref('')
const confirm = ref('')
const loading = ref(false)

async function submit() {
  if (!username.value || !password.value) return
  if (password.value.length < 6) {
    toast('密码至少 6 位', 'error')
    return
  }
  if (password.value !== confirm.value) {
    toast('两次密码不一致', 'error')
    return
  }
  loading.value = true
  try {
    const { data } = await api.post('/auth/register', {
      username: username.value,
      password: password.value,
    })
    auth.setAuth(data.token, data.user)
    toast('注册成功', 'success')
    router.push('/')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="max-w-sm mx-auto mt-16 px-4">
    <div class="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm">
      <h1 class="text-2xl font-bold text-slate-800 text-center">注册</h1>
      <p class="text-sm text-slate-400 text-center mt-1">加入校园二手集市</p>
      <form class="mt-6 space-y-4" @submit.prevent="submit">
        <div>
          <label class="block text-sm text-slate-600 mb-1">用户名</label>
          <input
            v-model="username"
            type="text"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            placeholder="2-50 个字符"
          />
        </div>
        <div>
          <label class="block text-sm text-slate-600 mb-1">密码</label>
          <input
            v-model="password"
            type="password"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            placeholder="至少 6 位"
          />
        </div>
        <div>
          <label class="block text-sm text-slate-600 mb-1">确认密码</label>
          <input
            v-model="confirm"
            type="password"
            class="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-300"
            placeholder="再次输入密码"
          />
        </div>
        <button
          type="submit"
          :disabled="loading"
          class="w-full py-2 rounded-lg bg-brand-600 text-white font-medium hover:bg-brand-700 disabled:opacity-60"
        >
          {{ loading ? '注册中…' : '注册' }}
        </button>
      </form>
      <p class="mt-4 text-sm text-center text-slate-400">
        已有账号？
        <router-link to="/login" class="text-brand-600 hover:underline">去登录</router-link>
      </p>
    </div>
  </div>
</template>

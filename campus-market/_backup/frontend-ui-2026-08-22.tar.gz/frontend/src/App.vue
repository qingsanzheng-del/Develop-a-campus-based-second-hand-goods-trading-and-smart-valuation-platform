<script setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import NavBar from './components/NavBar.vue'
import { useAuthStore } from './stores/auth'

const router = useRouter()
const auth = useAuthStore()
const toasts = ref([])

function addToast(e) {
  const { message, type = 'info' } = e.detail
  const id = Date.now() + Math.random()
  toasts.value.push({ id, message, type })
  setTimeout(() => {
    toasts.value = toasts.value.filter((t) => t.id !== id)
  }, 3200)
}

onMounted(() => {
  window.addEventListener('app:toast', addToast)
  window.addEventListener('app:unauthorized', () => {
    auth.logout()
    router.push('/login')
  })
})
</script>

<template>
  <div class="min-h-full flex flex-col">
    <NavBar />
    <main class="flex-1">
      <router-view />
    </main>
    <div class="fixed top-4 right-4 z-50 space-y-2 w-72">
      <div
        v-for="t in toasts"
        :key="t.id"
        class="px-4 py-2 rounded-xl shadow-lg text-sm text-white"
        :class="t.type === 'error' ? 'bg-rose-500' : t.type === 'success' ? 'bg-emerald-500' : 'bg-slate-700'"
      >
        {{ t.message }}
      </div>
    </div>
  </div>
</template>
